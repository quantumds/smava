# Directories:
data_dir = "C:/ANIBAL/FORMATION/PERSONAL/smava_julia/data/"
scripts_dir = "C:/ANIBAL/FORMATION/PERSONAL/smava_julia/scripts/"

# File names:
raw_file_name = "RAcredit_train.csv"

# Script names:
properties_name = "y_properties.jl"
