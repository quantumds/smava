# smava_julia
Smava project done in Julia
