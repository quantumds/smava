# SMAVA

The objective of this project is to utilize **SMAVA Online-Krediten** data set, to build a complete data science life-cycle.

* Define the problem
* Data understanding
* Data wrangling
* EDA - Exploratory Data Analysis (Descriptive analytics and visualization)
* Modelling
* Conclusions drawing
* Online App creation with results showing

Contributors:
The *Browski Brothers* from Latin DS Unit.
